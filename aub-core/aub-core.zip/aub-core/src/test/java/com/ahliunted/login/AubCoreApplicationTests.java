package com.ahliunted.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AubCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
